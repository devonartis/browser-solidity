# Automatic build
Built website from `10cdc1d`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-10cdc1d.zip`.
